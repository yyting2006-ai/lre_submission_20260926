ExecKG LaTeX source package

Main document: execkg_lre.tex
Bibliography: execkg_lre.bib
Class and bibliography style: sn-jnl.cls, sn-mathphys.bst
Figures: fig_concept.pdf, fig_operation.pdf, fig_pipeline.pdf, fig_results.pdf
Tables are embedded in execkg_lre.tex.
The source selects xeCJK under XeTeX and CJKutf8 under pdfLaTeX.

Compile with: tectonic execkg_lre.tex
